interface Rodas {
    public int getNumeroRodas();
}