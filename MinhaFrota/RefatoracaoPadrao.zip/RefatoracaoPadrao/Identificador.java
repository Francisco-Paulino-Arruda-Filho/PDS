interface identificador{
    public String getTipoVeiculo();
}