public class Funcionario {
	String nome;
	public Funcionario (String nome){
		this.nome = nome;
	}
}